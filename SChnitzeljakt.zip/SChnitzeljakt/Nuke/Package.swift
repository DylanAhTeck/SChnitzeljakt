import PackageDescription

let package = Package(
    name: "Nuke",
    exclude: ["Tests"] // excluding until all module layouts get supported
)
